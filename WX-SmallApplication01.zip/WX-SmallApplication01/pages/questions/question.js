// pages/questions/logs.js
Page({

    data: {
        grade: 0,
        resData: {
            "questions": [{
                    "title": "世界杯历史进球总数最多的是哪位球员",
                    "option": [{
                            "name": "克洛泽",
                            "url": '../srcs/ic_q1_a1.png'
                        },
                        {
                            "name": "罗纳尔多",
                            "url": '../srcs/ic_q1_a2.png'
                        },
                        {
                            "name": "李宇春",
                            "url": '../srcs/ic_q1_a3.png'
                        },
                        {
                            "name": "鹿晗",
                            "url": '../srcs/ic_q1_a4.png'
                        }
                    ],
                    "key": 0
                },
                {
                    "title": "全国人口334319人，去掉女人170503人，减掉18岁以下男人40122人，减去35岁以上男人85670人，太胖太瘦的24775人，捕鲸来不了的788人，监视火山走不开的321人，剪羊毛2856人，缺胳膊少腿的189人，队医厨师按摩师3人，教练1人。我的天！就剩23人了，结果就这23人，组成国家队，通过了欧洲区预选赛，成功的参加了本次世界杯，请问是哪个国家的球队",
                    "option": [{
                            "name": "塞内加尔",
                            "url": '../srcs/ic_q2_a1.png'
                        },
                        {
                            "name": "冰岛",
                            "url": '../srcs/ic_q2_a2.png'
                        },
                        {
                            "name": "塞尔维亚",
                            "url": '../srcs/ic_q2_a3.png'
                        },
                        {
                            "name": "巴拿马",
                            "url": '../srcs/ic_q2_a4.png'
                        }
                    ],
                    "key": 1
                }
            ],
            "achievement": {
                "1": "伪球迷",
                "2": "球迷",
                "3": "中超球星",
                "4": "欧洲球星",
                "5": "超级球星",
                "6": "球王",
                "7": "足协主席"
            },
            "honor": [{
                    "name": "金靴奖",
                    "url": ""
                },
                {
                    "name": "最佳球员",
                    "url": ""
                }
            ]
        },
        viewData: {},
        getTitle: "",
        questionIndex: 0,
        isTrue: -1
    },

    //点击答案
    checkAnswer(event) {
        let answerIndex = event.target.dataset.index;
        if (answerIndex == this.data.viewData.key) {
            this.setData({
                grade: this.data.grade + 1,
                isTrue: this.data.viewData.key
            })

        }
        setTimeout(() => {
            if (this.data.questionIndex < 1) {
                this.pushQuestion();
            } else if (this.data.questionIndex == 1) {
                this.setData({
                    getTitle: this.data.resData.achievement[this.data.grade]
                })
                wx.navigateTo({
                    url: '../achievement/achievement?title=' + this.data.getTitle
                })
            }
        }, 300)

    },

    //每次选择之后进入下一问题
    pushQuestion() {
        let questionIndex = this.data.questionIndex;
        this.setData({
            viewData: this.data.resData.questions[questionIndex + 1],
            questionIndex: questionIndex + 1,
            isTrue: -1
        });
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        this.setData({
            viewData: this.data.resData.questions[0],
            questionIndex: 0,
            isTrue: -1
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})