// pages/achievement/achievement.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        avatarUrl: '',
        nickName: '',
        title: '',
        isShow: false,
        shareImgSrc: ''
    },


    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        this.setData({
            title: options.title
        })

    },

    fenxiang() {
        // 使用 wx.createContext 获取绘图上下文 context
        let ctx = wx.createCanvasContext('firstCanvas');
        ctx.fillStyle = "white";
        ctx.fillRect(0,0,300,400);
        ctx.drawImage('../srcs/ic_achievement.jpg', 0, 0, 300, 300);
        //头像
        ctx.drawImage(this.data.avatarUrl, 10, 310, 30, 30);
        ctx.strokeStyle = '#73bac4';
        ctx.strokeRect(9, 309, 30, 30);
        ctx.drawImage('../srcs/ic_QRCode.png', 240, 350, 45, 45);
        ctx.setFontSize(14);
        ctx.fillStyle = "black";
        ctx.lineWidth = 1;
        ctx.fillText('我要参加世界杯!', 50, 320);
        let str = `${this.data.nickName}获得了'${this.data.title}'称号`;
        ctx.fillText(str, 50, 340);
        ctx.setFontSize(10);
        ctx.fillText('长按识别二维码进行挑战!', 10, 380);
        ctx.draw();
        this.setData({
            isShow: true
        })
    },

    saveImg() {
        let that = this;
        wx.canvasToTempFilePath({
            x: 0,
            y: 0,
            width: 300,
            height: 400,
            destWidth: 300,
            destHeight: 400,
            canvasId: 'firstCanvas',
            success: function(res) {
                console.log("canvas图片保存成功"+res.tempFilePath);
                that.setData({
                    shareImgSrc: res.tempFilePath
                })
                that.saveLocal();
            },
            fail: function(res) {
                console.log(res)
            }
        });

        
    },
    saveLocal(){
        let that = this
        wx.downloadFile({
            url: that.data.shareImgSrc,
            success(res) {
                console.log(res);
                wx.saveImageToPhotosAlbum({
                    filePath: res.tempFilePath,
                    success(res) {
                        console.log(res);
                        wx.showModal({
                            title: '存图成功',
                            content: '图片成功保存到相册了，去发圈噻~',
                            showCancel: false,
                            confirmText: '好哒',
                            confirmColor: '#72B9C3',
                            success: function (res) {
                                if (res.confirm) {
                                    console.log('用户点击确定');
                                }
                                // that.hideShareImg()
                            }
                        })
                    }
                })
            },
            fail(res) {
                console.log(res);
            }
        })
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function(e) {
        // this.setData({
        //     width:e.target.width
        // })
        let that = this;
        wx.getUserInfo({
            success: function(res) {
                that.setData({
                    avatarUrl: res.userInfo.avatarUrl,
                    nickName: res.userInfo.nickName,
                })
            }
        })
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})