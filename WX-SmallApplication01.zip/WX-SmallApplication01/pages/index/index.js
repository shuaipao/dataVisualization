//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    imgUrl: {
      ic_homeImg: "../srcs/ic_homeImg.png"
    },
    title:'我要参加世界杯'
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  footballer: function() {
    wx.navigateTo({
      url: '../questions/question?a=123'
    }) 
  },
  coach: function() {
    wx.showToast({
      title: 'coach',
      icon: 'success',
      duration: 2000
    })  
  },
  onLoad: function() {
      wx.getSystemInfo({
          success: function (res) {
              console.log(res);
          }
      }) 
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})